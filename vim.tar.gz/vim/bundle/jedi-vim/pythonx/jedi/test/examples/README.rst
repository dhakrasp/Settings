Examples
========

Here you can find project structures that match other Python projects. This is
then used to check if jedi understands these structures.
