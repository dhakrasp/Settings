foo = 'ns1_folder!'
